package com.tendencias.m5b.proyectousarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectousariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
