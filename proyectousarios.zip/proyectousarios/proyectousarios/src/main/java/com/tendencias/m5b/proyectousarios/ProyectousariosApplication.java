package com.tendencias.m5b.proyectousarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectousariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectousariosApplication.class, args);
	}

}
